<?php
include '../model/product_details.php';

$cat_id = $_GET['cat_id'];
$table = "products_table";
$col = "*";
var_dump($cat_id);
// $condition = "id = "
?>