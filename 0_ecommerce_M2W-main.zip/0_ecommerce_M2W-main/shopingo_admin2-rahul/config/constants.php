<?php
// BASE URL
define('BASE_URL', 'http://localhost/shopingo_admin/');
?>
