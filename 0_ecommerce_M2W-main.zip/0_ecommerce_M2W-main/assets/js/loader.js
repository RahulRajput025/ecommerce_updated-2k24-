



$(window).on('load', function () {
  $('.loader-wrapper').fadeOut(1000);
}) 

