<?php
include '../../includes/header.php';
?>


<!--end breadcrumb-->
<div class="container">
    <div class="row justify-content-center  ">
        <h1 style="align-items: center; margin-top: 300px; " class="text-center  text-danger">Currently We Are Not
            Receving Orders.... Thankyou</h1>
        <a href="./index.php" class="text-center mt-5" ><button style="width:fit-content; margin:auto;"
                class="btn btn-secondary  ">Back to Homepage</button></a>
    </div>
</div>




<!-- JavaScript files -->
<script src="../../assets/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/jquery.min.js"></script>
<script src="../../assets/plugins/slick/slick.min.js"></script>
<script src="../../assets/js/main.js"></script>
<script src="../../assets/js/loader.js"></script>


</body>

</html>