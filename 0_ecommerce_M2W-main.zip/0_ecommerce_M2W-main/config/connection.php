<?php
$conn = mysqli_connect("localhost", "phpmyadmin", "root", "ecommerce") or die ("connection unsuccessful");
?> 